package com.example.myaiapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.CancellationSignal;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001, PICK_MOVE_TREE = 1002;
    private Uri treeUri;
    private String currentId;
    private final ArrayDeque<String> parents = new ArrayDeque<>();
    private LinearLayout root, listBox, chips;
    private EditText searchBox;
    private TextView locationText, summaryText, emptyText, selectionText;
    private final List<FileEntry> files = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private String filter = "", category = "全部";
    private boolean selectionMode = false;
    private boolean thumbnailMode = false;\n    private FileEntry pendingMove;
    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);

    private static class FileEntry {
        Uri uri; String id, name, mime; boolean directory; long size;
        FileEntry(Uri u, String i, String n, String m, boolean d, long s) { uri=u; id=i; name=n; mime=m; directory=d; size=s; }
    }

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildUi(); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String value, int size, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t; }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,248,250));
        root.setPadding(dp(16), dp(14), dp(16), dp(8)); setContentView(root);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("My AI App", 26, Color.rgb(28,34,44)); brand.setTypeface(null, 1); top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button recent = button("最近"); recent.setOnClickListener(v -> showRecent()); top.addView(recent);
        Button analyze = button("存储分析"); analyze.setOnClickListener(v -> analyzeStorage()); top.addView(analyze);
        Button choose = button("选择位置"); choose.setOnClickListener(v -> pickFolder()); top.addView(choose); root.addView(top);
        TextView subtitle = text("文件管理 · 图片 · 视频 · 音频 · 文档", 12, Color.rgb(117,125,139)); subtitle.setPadding(0,dp(4),0,dp(12)); root.addView(subtitle);

        LinearLayout summary = new LinearLayout(this); summary.setOrientation(LinearLayout.VERTICAL); summary.setPadding(dp(14),dp(12),dp(14),dp(12)); summary.setBackground(roundBg(Color.WHITE,dp(15)));
        summary.addView(text("当前位置",12,Color.GRAY)); locationText=text("尚未选择文件夹",15,Color.rgb(38,45,56)); locationText.setPadding(0,dp(5),0,0); summary.addView(locationText);
        summaryText=text("选择文件夹后即可查看文件概况",12,Color.GRAY); summaryText.setPadding(0,dp(6),0,0); summary.addView(summaryText); root.addView(summary);

        searchBox = new EditText(this); searchBox.setSingleLine(true); searchBox.setTextSize(14); searchBox.setHint("搜索当前文件夹"); searchBox.setPadding(dp(13),0,dp(13),0); searchBox.setBackground(roundBg(Color.WHITE,dp(12)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,dp(46)); sp.setMargins(0,dp(12),0,dp(9)); root.addView(searchBox,sp);
        searchBox.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){filter=s.toString().toLowerCase(Locale.ROOT);renderFiles();} public void afterTextChanged(Editable e){} });

        chips=new LinearLayout(this); chips.setOrientation(LinearLayout.HORIZONTAL); String[] cats={"全部","图片","视频","音频","文档"};
        for(String c:cats){Button b=button(c); b.setMinWidth(0); b.setPadding(dp(9),0,dp(9),0); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(36),1);p.setMargins(0,0,dp(5),0);chips.addView(b,p);b.setOnClickListener(v->{category=c;updateChips();renderFiles();});} root.addView(chips);
        updateChips();

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(0,dp(9),0,0);
        Button back=button("返回上级");back.setOnClickListener(v->goUp());actions.addView(back,new LinearLayout.LayoutParams(0,dp(40),1));
        Button refresh=button("刷新");refresh.setOnClickListener(v->loadFiles());LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(40),1);rp.setMargins(dp(6),0,0,0);actions.addView(refresh,rp);
        Button folder=button("新建文件夹");folder.setOnClickListener(v->createFolder());LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(40),1);fp.setMargins(dp(6),0,0,0);actions.addView(folder,fp);root.addView(actions);

        LinearLayout selectBar=new LinearLayout(this);selectBar.setGravity(Gravity.CENTER_VERTICAL);selectBar.setPadding(0,dp(10),0,dp(4));
        selectionText=text("长按文件可多选",12,Color.GRAY);selectBar.addView(selectionText,new LinearLayout.LayoutParams(0,-2,1));
        Button view=button("缩略图");view.setOnClickListener(v->{thumbnailMode=!thumbnailMode;view.setText(thumbnailMode?"列表":"缩略图");renderFiles();});selectBar.addView(view);Button zip=button("压缩所选");zip.setOnClickListener(v->compressSelected());selectBar.addView(zip);Button bulk=button("批量删除");bulk.setOnClickListener(v->bulkDelete());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(38));bp.setMargins(dp(6),0,0,0);selectBar.addView(bulk,bp);root.addView(selectBar);
        ScrollView scroll=new ScrollView(this);listBox=new LinearLayout(this);listBox.setOrientation(LinearLayout.VERTICAL);scroll.addView(listBox);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        emptyText=text("选择一个文件夹，开始管理手机文件。",14,Color.GRAY);emptyText.setGravity(Gravity.CENTER);emptyText.setPadding(dp(12),dp(28),dp(12),dp(28));listBox.addView(emptyText);
        TextView footer=text("仅访问你主动授权的位置 · 长按可批量选择",10,Color.GRAY);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(8),0,dp(3));root.addView(footer);
    }

    private void updateChips(){for(int i=0;i<chips.getChildCount();i++){Button b=(Button)chips.getChildAt(i);boolean on=b.getText().toString().equals(category);b.setTextColor(on?Color.WHITE:Color.rgb(54,91,151));b.setBackground(roundBg(on?Color.rgb(55,111,190):Color.WHITE,dp(11)));}}
    private android.graphics.drawable.GradientDrawable roundBg(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(dp(1),Color.rgb(235,237,241));return d;}
    private Button button(String title){Button b=new Button(this);b.setText(title);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(Color.rgb(40,91,180));b.setPadding(dp(8),0,dp(8),0);b.setBackground(roundBg(Color.WHITE,dp(11)));return b;}

    private void pickFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_TREE);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==PICK_MOVE_TREE&&result==RESULT_OK&&data!=null&&pendingMove!=null){
            Uri destTree=data.getData(); int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try{getContentResolver().takePersistableUriPermission(destTree,flags);String destId=DocumentsContract.getTreeDocumentId(destTree);safeMove(pendingMove,DocumentsContract.buildDocumentUriUsingTree(destTree,destId));}
            catch(Exception e){toast("移动准备失败："+e.getMessage());} finally {pendingMove=null;}
        }
        if(request==PICK_TREE&&result==RESULT_OK&&data!=null){treeUri=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);try{getContentResolver().takePersistableUriPermission(treeUri,flags);}catch(Exception ignored){}currentId=DocumentsContract.getTreeDocumentId(treeUri);parents.clear();selected.clear();selectionMode=false;loadFiles();}}
    private Uri docUri(String id){return DocumentsContract.buildDocumentUriUsingTree(treeUri,id);}
    private Uri childrenUri(String id){return DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,id);}
    private void goUp(){if(treeUri==null)return;if(parents.isEmpty()){toast("已经是授权目录的顶层");return;}currentId=parents.pop();selected.clear();selectionMode=false;loadFiles();}

    private void loadFiles(){if(treeUri==null){toast("请先选择文件夹");return;}files.clear();Cursor c=null;long total=0;int count=0;try{c=getContentResolver().query(childrenUri(currentId),new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE},null,null,null);if(c!=null)while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),mime=c.getString(2);long size=c.isNull(3)?0:c.getLong(3);files.add(new FileEntry(docUri(id),id,name,mime,DocumentsContract.Document.MIME_TYPE_DIR.equals(mime),size));if(!DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){total+=size;count++;}}}catch(Exception e){toast("读取失败："+e.getMessage());}finally{if(c!=null)c.close();}
        Collections.sort(files,Comparator.comparing((FileEntry f)->!f.directory).thenComparing(f->f.name.toLowerCase(Locale.ROOT)));
        String path=treeUri.getLastPathSegment()==null?"已授权目录":treeUri.getLastPathSegment().replace(':','/');locationText.setText(path+(parents.isEmpty()?"":" / 子目录"));summaryText.setText(files.size()+" 个项目 · "+count+" 个文件 · 当前层约 "+formatSize(total));renderFiles();}

    private boolean matchesCategory(FileEntry f){if(f.directory||category.equals("全部"))return true;String m=f.mime==null?"":f.mime.toLowerCase(Locale.ROOT);String n=f.name.toLowerCase(Locale.ROOT);switch(category){case "图片":return m.startsWith("image/")||ends(n,"jpg","jpeg","png","gif","webp","heic");case "视频":return m.startsWith("video/")||ends(n,"mp4","mkv","mov","avi","webm");case "音频":return m.startsWith("audio/")||ends(n,"mp3","wav","m4a","aac","flac","ogg");case "文档":return m.contains("pdf")||m.contains("text")||m.contains("word")||m.contains("sheet")||ends(n,"pdf","txt","doc","docx","xls","xlsx","ppt","pptx","zip");default:return true;}}
    private boolean ends(String name,String...ext){for(String e:ext)if(name.endsWith("."+e))return true;return false;}
    private void renderFiles(){
        if(listBox==null)return;
        listBox.removeAllViews();
        List<FileEntry> visible=new ArrayList<>();
        for(FileEntry f:files)if(f.name.toLowerCase(Locale.ROOT).contains(filter)&&matchesCategory(f))visible.add(f);
        boolean grid=thumbnailMode && (category.equals("图片")||category.equals("视频")||category.equals("全部"));
        if(grid){
            LinearLayout row=null; int col=0;
            for(FileEntry f:visible){
                if(col==0){row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,0,0,dp(8));listBox.addView(row,rp);}
                LinearLayout cell=new LinearLayout(this);cell.setOrientation(LinearLayout.VERTICAL);cell.setPadding(dp(8),dp(8),dp(8),dp(8));cell.setBackground(roundBg(Color.WHITE,dp(13)));
                LinearLayout.LayoutParams cellp=new LinearLayout.LayoutParams(0,-2,1);if(col==0)cellp.setMargins(0,0,dp(6),0);else cellp.setMargins(dp(6),0,0,0);row.addView(cell,cellp);
                ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setBackground(roundBg(Color.rgb(240,243,247),dp(10)));thumb.setImageResource(android.R.drawable.ic_menu_gallery);
                LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(112));cell.addView(thumb,tp);
                if(!f.directory && f.mime!=null && (f.mime.startsWith("image/")||f.mime.startsWith("video/")))loadThumbnailAsync(f,thumb);
                TextView nm=text((f.directory?"📁 ":"")+f.name,12,Color.rgb(35,42,54));nm.setMaxLines(2);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(0,dp(7),0,dp(3));cell.addView(nm);
                TextView meta=text(f.directory?"文件夹":formatSize(f.size)+(f.mime!=null&&f.mime.startsWith("video/")?" · 视频":" · 图片"),10,Color.GRAY);cell.addView(meta);
                if(selectionMode){android.widget.CheckBox cb=new android.widget.CheckBox(this);cb.setChecked(selected.contains(f.id));cb.setOnCheckedChangeListener((v,checked)->{if(checked)selected.add(f.id);else selected.remove(f.id);selectionText.setText("已选择 "+selected.size()+" 项");});cell.addView(cb);}
                cell.setOnClickListener(v->{if(selectionMode){if(selected.contains(f.id))selected.remove(f.id);else selected.add(f.id);renderFiles();selectionText.setText("已选择 "+selected.size()+" 项");}else if(f.directory){parents.push(currentId);currentId=f.id;loadFiles();}else openFile(f);});
                cell.setOnLongClickListener(v->{selectionMode=true;selected.add(f.id);renderFiles();selectionText.setText("已选择 "+selected.size()+" 项");return true;});
                col++;if(col==2)col=0;
            }
            if(visible.size()%2==1){View spacer=new View(this);row.addView(spacer,new LinearLayout.LayoutParams(0,dp(1),1));}
        }else{
            for(FileEntry f:visible){
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(10),dp(7),dp(10));card.setBackground(roundBg(Color.WHITE,dp(13)));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(7));listBox.addView(card,cp);
                if(selectionMode){android.widget.CheckBox cb=new android.widget.CheckBox(this);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(55,111,190)));cb.setChecked(selected.contains(f.id));cb.setOnCheckedChangeListener((v,checked)->{if(checked)selected.add(f.id);else selected.remove(f.id);selectionText.setText("已选择 "+selected.size()+" 项");});card.addView(cb);}
                TextView ico=text(f.directory?"📁":iconFor(f),22,Color.BLACK);card.addView(ico,new LinearLayout.LayoutParams(dp(38),-2));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView name=text(f.name,14,Color.rgb(35,42,54));name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(name);TextView meta=text(f.directory?"文件夹":formatSize(f.size)+" · "+typeName(f.mime),10,Color.GRAY);meta.setPadding(0,dp(3),0,0);info.addView(meta);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));Button more=button("管理");more.setMinWidth(dp(50));more.setOnClickListener(v->fileMenu(f));card.addView(more);
                card.setOnClickListener(v->{if(selectionMode){if(selected.contains(f.id))selected.remove(f.id);else selected.add(f.id);renderFiles();selectionText.setText("已选择 "+selected.size()+" 项");}else if(f.directory){parents.push(currentId);currentId=f.id;loadFiles();}else openFile(f);});card.setOnLongClickListener(v->{selectionMode=true;selected.add(f.id);renderFiles();selectionText.setText("已选择 "+selected.size()+" 项");return true;});
            }
        }
        if(visible.isEmpty()){TextView t=text(files.isEmpty()?"这里还没有文件。":"没有符合条件的项目。",14,Color.GRAY);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(30),dp(10),dp(30));listBox.addView(t);}
    }

    private void loadThumbnailAsync(FileEntry file, ImageView target){
        target.setTag(file.uri.toString());
        if(Build.VERSION.SDK_INT<29)return;
        thumbnailExecutor.execute(()->{
            try{
                Bitmap bitmap=getContentResolver().loadThumbnail(file.uri,new android.util.Size(480,360),new CancellationSignal());
                runOnUiThread(()->{if(file.uri.toString().equals(target.getTag()))target.setImageBitmap(bitmap);});
            }catch(Exception ignored){}
        });
    }
    private String iconFor(FileEntry f){String m=f.mime==null?"":f.mime; if(m.startsWith("image/"))return "🖼️";if(m.startsWith("video/"))return "🎬";if(m.startsWith("audio/"))return "🎵";if(m.contains("pdf"))return "📕";if(m.contains("zip"))return "🗜️";return "📄";}
    private String typeName(String mime){if(mime==null)return "文件";if(mime.startsWith("image/"))return "图片";if(mime.startsWith("video/"))return "视频";if(mime.startsWith("audio/"))return "音频";if(mime.contains("pdf"))return "PDF";return "文件";}
    private String formatSize(long n){if(n<1024)return n+" B";if(n<1048576)return new DecimalFormat("0.0").format(n/1024.0)+" KB";if(n<1073741824)return new DecimalFormat("0.0").format(n/1048576.0)+" MB";return new DecimalFormat("0.0").format(n/1073741824.0)+" GB";}

    private void fileMenu(FileEntry f){List<String> opts=new ArrayList<>();opts.add("打开");if(!f.directory)opts.add("分享");opts.add("重命名");if(!f.directory)opts.add("复制到当前文件夹");if(!f.directory)opts.add("安全移动到其他文件夹");if(!f.directory&&f.name.toLowerCase(Locale.ROOT).endsWith(".zip"))opts.add("解压到当前文件夹");opts.add("删除");String[] a=opts.toArray(new String[0]);new AlertDialog.Builder(this).setTitle(f.name).setItems(a,(d,w)->{String op=a[w];if(op.equals("打开")){if(f.directory){parents.push(currentId);currentId=f.id;loadFiles();}else openFile(f);}else if(op.equals("分享"))shareFile(f);else if(op.equals("重命名"))renameFile(f);else if(op.equals("复制到当前文件夹"))copyFile(f);else if(op.equals("安全移动到其他文件夹"))chooseMoveDestination(f);else if(op.equals("解压到当前文件夹"))unzipFile(f);else if(op.equals("删除"))deleteFile(f);}).show();}
    private void openFile(FileEntry f){saveRecent(f);try{String mime=f.mime==null||f.mime.equals("application/octet-stream")?"*/*":f.mime;Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(f.uri,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){toast("没有找到可打开此文件的应用");}}
    private void shareFile(FileEntry f){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType(f.mime==null?"*/*":f.mime);i.putExtra(Intent.EXTRA_STREAM,f.uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"分享文件"));}catch(Exception e){toast("分享失败");}}
    private void inputDialog(String title,String hint,String initial,java.util.function.Consumer<String> action){EditText edit=new EditText(this);edit.setSingleLine(true);edit.setHint(hint);if(initial!=null)edit.setText(initial);new AlertDialog.Builder(this).setTitle(title).setView(edit).setNegativeButton("取消",null).setPositiveButton("确定",(d,w)->{String s=edit.getText().toString().trim();if(!s.isEmpty())action.accept(s);}).show();}
    private void renameFile(FileEntry f){inputDialog("重命名","输入新名称",f.name,n->{try{DocumentsContract.renameDocument(getContentResolver(),f.uri,n);loadFiles();}catch(Exception e){toast("重命名失败："+e.getMessage());}});}
    private void deleteFile(FileEntry f){new AlertDialog.Builder(this).setTitle("删除项目？").setMessage("确定删除“"+f.name+"”吗？此操作可能无法撤销。 ").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{try{DocumentsContract.deleteDocument(getContentResolver(),f.uri);loadFiles();}catch(Exception e){toast("删除失败："+e.getMessage());}}).show();}
    private void bulkDelete(){if(selected.isEmpty()){toast("请先长按项目进行多选");return;}new AlertDialog.Builder(this).setTitle("批量删除").setMessage("确定删除已选择的 "+selected.size()+" 个项目吗？此操作可能无法撤销。 ").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{int ok=0;for(FileEntry f:new ArrayList<>(files))if(selected.contains(f.id)){try{if(DocumentsContract.deleteDocument(getContentResolver(),f.uri))ok++;}catch(Exception ignored){}}selected.clear();selectionMode=false;loadFiles();toast("已删除 "+ok+" 项");}).show();}
    private void createFolder(){if(treeUri==null){toast("请先选择文件夹");return;}inputDialog("新建文件夹","文件夹名称",null,n->{try{DocumentsContract.createDocument(getContentResolver(),docUri(currentId),DocumentsContract.Document.MIME_TYPE_DIR,n);loadFiles();}catch(Exception e){toast("创建失败："+e.getMessage());}});}
    private void copyFile(FileEntry f){inputDialog("复制文件","新文件名称",f.name,n->{try{Uri target=DocumentsContract.createDocument(getContentResolver(),docUri(currentId),f.mime==null?"application/octet-stream":f.mime,n);if(target==null)throw new Exception("无法创建目标文件");try(InputStream in=getContentResolver().openInputStream(f.uri);OutputStream out=getContentResolver().openOutputStream(target)){if(in==null||out==null)throw new Exception("无法读取或写入文件");byte[] buf=new byte[16384];int len;while((len=in.read(buf))>0)out.write(buf,0,len);}loadFiles();toast("复制完成");}catch(Exception e){toast("复制失败："+e.getMessage());}});}


    private void compressSelected(){
        List<FileEntry> targets=new ArrayList<>();for(FileEntry f:files)if(selected.contains(f.id)&&!f.directory)targets.add(f);
        if(targets.isEmpty()){toast("请先长按并选择至少一个文件（暂不压缩文件夹）");return;}
        inputDialog("创建 ZIP 压缩包","压缩包名称（无需输入 .zip）","MyAIApp_Archive",name->{String zipName=name.toLowerCase(Locale.ROOT).endsWith(".zip")?name:name+".zip";try{Uri target=DocumentsContract.createDocument(getContentResolver(),docUri(currentId),"application/zip",zipName);if(target==null)throw new Exception("无法创建压缩包");try(OutputStream raw=getContentResolver().openOutputStream(target);ZipOutputStream zout=new ZipOutputStream(raw)){byte[] buf=new byte[16384];for(FileEntry f:targets){zout.putNextEntry(new ZipEntry(f.name));try(InputStream in=getContentResolver().openInputStream(f.uri)){if(in==null)throw new Exception("无法读取："+f.name);int len;while((len=in.read(buf))>0)zout.write(buf,0,len);}zout.closeEntry();}}selected.clear();selectionMode=false;loadFiles();toast("压缩完成："+targets.size()+" 个文件");}catch(Exception e){toast("压缩失败："+e.getMessage());}});
    }
    private void unzipFile(FileEntry f){new AlertDialog.Builder(this).setTitle("解压 ZIP").setMessage("将压缩包内容解压到当前文件夹。若存在同名文件，系统可能拒绝覆盖。是否继续？").setNegativeButton("取消",null).setPositiveButton("解压",(d,w)->{int done=0;try(InputStream raw=getContentResolver().openInputStream(f.uri);ZipInputStream zin=new ZipInputStream(raw)){ZipEntry e;byte[] buf=new byte[8192];while((e=zin.getNextEntry())!=null){String name=e.getName();if(name.startsWith("/")||name.contains("..")||name.contains("\\")){zin.closeEntry();continue;}Uri outUri;if(e.isDirectory()){String dirName=name.endsWith("/")?name.substring(0,name.length()-1):name;outUri=DocumentsContract.createDocument(getContentResolver(),docUri(currentId),DocumentsContract.Document.MIME_TYPE_DIR,dirName);}else{int slash=name.lastIndexOf('/');String base=slash>=0?name.substring(slash+1):name;if(base.isEmpty()){zin.closeEntry();continue;}outUri=DocumentsContract.createDocument(getContentResolver(),docUri(currentId),"application/octet-stream",base);}if(outUri!=null&&!e.isDirectory()){try(OutputStream out=getContentResolver().openOutputStream(outUri)){if(out!=null){int len;while((len=zin.read(buf))>0)out.write(buf,0,len);done++;}}}zin.closeEntry();}loadFiles();toast("解压完成："+done+" 个文件");}catch(Exception ex){toast("解压失败："+ex.getMessage());}}).show();}

    private void saveRecent(FileEntry f){
        try{
            android.content.SharedPreferences sp=getSharedPreferences("recent_files",MODE_PRIVATE);
            String key=f.uri.toString(); String old=sp.getString("items","");
            ArrayList<String> items=new ArrayList<>(); if(!old.isEmpty())for(String x:old.split("\n"))if(!x.startsWith(key+"\t"))items.add(x);
            items.add(0,key+"\t"+f.name+"\t"+(f.mime==null?"*/*":f.mime));
            while(items.size()>20)items.remove(items.size()-1);
            sp.edit().putString("items",android.text.TextUtils.join("\n",items)).apply();
        }catch(Exception ignored){}
    }
    private void showRecent(){
        String raw=getSharedPreferences("recent_files",MODE_PRIVATE).getString("items","");
        if(raw.isEmpty()){toast("还没有最近打开的文件");return;}
        String[] rows=raw.split("\n");ArrayList<String> labels=new ArrayList<>();ArrayList<Uri> uris=new ArrayList<>();
        for(String row:rows){String[] a=row.split("\t",3);if(a.length==3)try{uris.add(Uri.parse(a[0]));labels.add(a[1]);}catch(Exception ignored){}}
        if(labels.isEmpty()){toast("最近记录不可用");return;}
        new AlertDialog.Builder(this).setTitle("最近打开").setItems(labels.toArray(new String[0]),(d,w)->{try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uris.get(w),"*/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){toast("文件可能已移动或授权已失效");}}).setPositiveButton("清空记录",(d,w)->getSharedPreferences("recent_files",MODE_PRIVATE).edit().clear().apply()).show();
    }
    private void analyzeStorage(){
        if(treeUri==null){toast("请先选择文件夹");return;}
        toast("正在统计当前授权文件夹…");
        thumbnailExecutor.execute(()->{
            long[] stats=new long[]{0,0,0,0}; // bytes, files, folders, unknown-size files
            analyzeDocument(currentId,stats,0);
            runOnUiThread(()->new AlertDialog.Builder(this).setTitle("当前文件夹存储分析")
                .setMessage("文件数量："+stats[1]+"\\n文件夹数量："+stats[2]+"\\n可统计大小："+formatSize(stats[0])+"\\n大小未知的文件："+stats[3]+"\\n\\n仅统计当前目录及其子目录，不代表整部手机。")
                .setPositiveButton("知道了",null).show());
        });
    }
    private void analyzeDocument(String id,long[] stats,int depth){
        if(depth>30)return;
        Cursor c=null;
        try{
            c=getContentResolver().query(childrenUri(id),new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE},null,null,null);
            if(c!=null)while(c.moveToNext()){
                String child=c.getString(0),mime=c.getString(1);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){stats[2]++;analyzeDocument(child,stats,depth+1);}
                else{stats[1]++;if(c.isNull(2)||c.getLong(2)<0)stats[3]++;else stats[0]+=c.getLong(2);}
            }
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
    }
    private void chooseMoveDestination(FileEntry f){
        pendingMove=f;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_MOVE_TREE);
    }
    private void safeMove(FileEntry source,Uri destinationFolder){
        new AlertDialog.Builder(this).setTitle("安全移动文件")
            .setMessage("将先复制到目标文件夹，核对复制前后的字节数，确认一致后才删除原文件。是否继续？")
            .setNegativeButton("取消",null).setPositiveButton("继续",(d,w)->{
                try{
                    String mime=source.mime==null?"application/octet-stream":source.mime;
                    Uri target=DocumentsContract.createDocument(getContentResolver(),destinationFolder,mime,source.name);
                    if(target==null)throw new Exception("目标文件创建失败");
                    long written=0;byte[] buf=new byte[32768];
                    try(InputStream in=getContentResolver().openInputStream(source.uri);OutputStream out=getContentResolver().openOutputStream(target)){
                        if(in==null||out==null)throw new Exception("无法读取源文件或写入目标文件");
                        int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);written+=n;}
                    }
                    long actual=0;
                    try(InputStream in=getContentResolver().openInputStream(target)){if(in==null)throw new Exception("无法验证目标文件");int n;while((n=in.read(buf))!=-1)actual+=n;}
                    if(actual!=written)throw new Exception("复制校验未通过，原文件已保留");
                    if(!DocumentsContract.deleteDocument(getContentResolver(),source.uri))throw new Exception("复制已完成，但系统未能删除原文件；请检查是否存在两份文件");
                    loadFiles();toast("移动成功，复制内容已验证");
                }catch(Exception e){toast("移动未完全完成："+e.getMessage()+"；请检查目标文件夹");}
            }).show();
    }
\n    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
